-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 07, 2020 at 05:52 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `result`
--

-- --------------------------------------------------------

--
-- Table structure for table `3_to_5_student_result`
--

CREATE TABLE `3_to_5_student_result` (
  `ROLL_NO` varchar(45) DEFAULT NULL,
  `GR_NO` varchar(45) DEFAULT NULL,
  `STD` varchar(45) DEFAULT NULL,
  `CLASS` varchar(45) DEFAULT NULL,
  `NAME` varchar(200) DEFAULT NULL,
  `BIRTHDATE` varchar(45) DEFAULT NULL,
  `GUJARATI` int(11) DEFAULT NULL,
  `GUJARATI_GRADE` varchar(45) DEFAULT NULL,
  `MATHS` int(11) DEFAULT NULL,
  `MATHS_GRADE` varchar(45) DEFAULT NULL,
  `HINDI` int(11) DEFAULT NULL,
  `HINDI_GRADE` varchar(45) DEFAULT NULL,
  `ENGLISH` int(11) DEFAULT NULL,
  `ENGLISH_GRADE` varchar(45) DEFAULT NULL,
  `ENVIRONMENT` int(11) DEFAULT NULL,
  `ENVIRONMENT_GRADE` varchar(45) DEFAULT NULL,
  `VYAKTITVA_VIKAS` int(11) DEFAULT NULL,
  `VYAKTITVA_VIKAS_GRADE` varchar(45) DEFAULT NULL,
  `FINAL_TOTAL` int(11) DEFAULT NULL,
  `FINAL_GRADE` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `3_to_5_student_result`
--

INSERT INTO `3_to_5_student_result` (`ROLL_NO`, `GR_NO`, `STD`, `CLASS`, `NAME`, `BIRTHDATE`, `GUJARATI`, `GUJARATI_GRADE`, `MATHS`, `MATHS_GRADE`, `HINDI`, `HINDI_GRADE`, `ENGLISH`, `ENGLISH_GRADE`, `ENVIRONMENT`, `ENVIRONMENT_GRADE`, `VYAKTITVA_VIKAS`, `VYAKTITVA_VIKAS_GRADE`, `FINAL_TOTAL`, `FINAL_GRADE`) VALUES
('TOTAL_MARKS', '-', '-', '-', '-', '-', 160, '-', 160, '', 160, '', 160, '', 160, '', 200, '', 0, ''),
('1', '4650', '5', 'B', 'ભાયા  અકીલ  જાકુબ ', '40246', 134, 'A', 128, 'A', 124, 'B', 122, 'B', 136, 'A', 171, 'A', 815, 'A'),
('2', '4654', '5', 'B', 'ભાયા  તબરેઝ અસલમ ', '39996', 146, 'A', 128, 'A', 120, 'B', 122, 'B', 143, 'A', 170, 'A', 829, 'A'),
('45', '5415', '5', 'B', 'ભાયા  તાયરા  આમીન ', '39787', 90, 'C', 108, 'B', 101, 'C', 97, 'C', 120, 'B', 143, 'B', 659, 'B');

-- --------------------------------------------------------

--
-- Table structure for table `6_to_8_student_result`
--

CREATE TABLE `6_to_8_student_result` (
  `ROLL_NO` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GR_NO` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `STD` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `CLASS` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `NAME` varchar(200) COLLATE utf8_unicode_ci DEFAULT NULL,
  `BIRTHDATE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `GUJARATI` int(11) DEFAULT NULL,
  `GUJARATI_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `MATHS` int(11) DEFAULT NULL,
  `MATHS_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `HINDI` int(11) DEFAULT NULL,
  `HINDI_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ENGLISH` int(11) DEFAULT NULL,
  `ENGLISH_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SCIENCE` int(11) DEFAULT NULL,
  `SCIENCE_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SOCIAL_SCIENCE` int(11) DEFAULT NULL,
  `SOCIAL_SCIENCE_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SANSKRIT` int(11) DEFAULT NULL,
  `SANSKRIT_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `VYAKTITVA_VIKAS` int(11) DEFAULT NULL,
  `VYAKTITVA_VIKAS_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `FINAL_TOTAL` int(11) DEFAULT NULL,
  `FINAL_GRADE` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `USER_NAME` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `PASSWORD` varchar(45) COLLATE utf8_unicode_ci DEFAULT NULL,
  `SCHOOL_NAME` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `PR_CHKH` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `PR_CHKL` varchar(5) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`USER_NAME`, `PASSWORD`, `SCHOOL_NAME`, `PR_CHKH`, `PR_CHKL`) VALUES
('admin', 'admin', 'વાઘેરવાસ ', '70', '65');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
